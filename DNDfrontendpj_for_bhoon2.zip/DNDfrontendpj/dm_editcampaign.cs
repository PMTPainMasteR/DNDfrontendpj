﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DNDfrontendpj
{
    public partial class dm_editcampaign : Form
    {
        public dm_editcampaign()
        {
            InitializeComponent();
        }
    }
}
