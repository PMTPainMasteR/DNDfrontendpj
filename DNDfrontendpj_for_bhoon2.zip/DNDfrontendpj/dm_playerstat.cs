﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DNDfrontendpj
{
    public partial class dm_playerstat : Form
    {
        public dm_playerstat()
        {
            InitializeComponent();
        }

        private void viewinvenBT_Click(object sender, EventArgs e)
        {
            player_inventory inventory = new player_inventory();
            inventory.Show();
            this.Close();
        }

        private void addnewcharBT_Click(object sender, EventArgs e)
        {
            createnewchara createnewchara = new createnewchara();
            createnewchara.Show();
            //this.Close();
        }

        private void searchcharBT_Click(object sender, EventArgs e)
        {
            searchchar searchchar = new searchchar();
            searchchar.Show();

        }

        private void EditcharacterBT_Click(object sender, EventArgs e)
        {
            dm_editchara dm_Editchara = new dm_editchara();
            dm_Editchara.Show();

        }

        private void editcampaignBT_Click(object sender, EventArgs e)
        {
            dm_editcampaign dm_Editcampaign = new dm_editcampaign();
            dm_Editcampaign.Show();

        }
    }
}
