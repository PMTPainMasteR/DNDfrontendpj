﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DNDfrontendpj
{
    public partial class dm_newcampaign : Form
    {
        public dm_newcampaign()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //return to all dm campaign overview

            dm_allcampaign dm_Allcampaign = new dm_allcampaign();
            dm_Allcampaign.Show();
            this.Close();
        }

        private void startcampaignBT_Click(object sender, EventArgs e)
        {
            dm_playerstat dm_Playerstat = new dm_playerstat();
            dm_Playerstat.Show();
            this.Close();
        }
    }
}
