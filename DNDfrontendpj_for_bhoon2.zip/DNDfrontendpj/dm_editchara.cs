﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DNDfrontendpj
{
    public partial class dm_editchara : Form
    {
        public dm_editchara()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dm_playerstat dm_Playerstat = new dm_playerstat();
            dm_Playerstat.Show();
            this.Close();

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            //does nothing

        }

        private void ret2dmcharstat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
