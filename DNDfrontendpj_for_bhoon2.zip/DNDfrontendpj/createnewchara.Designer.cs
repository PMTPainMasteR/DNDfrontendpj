﻿namespace DNDfrontendpj
{
    partial class createnewchara
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label3 = new Label();
            textBox3 = new TextBox();
            label4 = new Label();
            textBox4 = new TextBox();
            label5 = new Label();
            textBox5 = new TextBox();
            label6 = new Label();
            groupBox1 = new GroupBox();
            label21 = new Label();
            textBox10 = new TextBox();
            label20 = new Label();
            label19 = new Label();
            textBox8 = new TextBox();
            label18 = new Label();
            textBox7 = new TextBox();
            label17 = new Label();
            label16 = new Label();
            label15 = new Label();
            label13 = new Label();
            textBox13 = new TextBox();
            label14 = new Label();
            label11 = new Label();
            textBox11 = new TextBox();
            label12 = new Label();
            label9 = new Label();
            textBox9 = new TextBox();
            label10 = new Label();
            label8 = new Label();
            textBox6 = new TextBox();
            label7 = new Label();
            groupBox2 = new GroupBox();
            textBox15 = new TextBox();
            textBox14 = new TextBox();
            textBox12 = new TextBox();
            label24 = new Label();
            label23 = new Label();
            label22 = new Label();
            label25 = new Label();
            label26 = new Label();
            label27 = new Label();
            richTextBox1 = new RichTextBox();
            richTextBox2 = new RichTextBox();
            richTextBox3 = new RichTextBox();
            saveandrettocampaignDB = new Button();
            retBT = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Verdana", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(91, 120, 105);
            label1.Location = new Point(21, 25);
            label1.Name = "label1";
            label1.Size = new Size(558, 48);
            label1.TabIndex = 7;
            label1.Text = "Create a New Character";
            label1.TextAlign = ContentAlignment.TopCenter;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(91, 120, 105);
            label2.Location = new Point(25, 103);
            label2.Name = "label2";
            label2.Size = new Size(142, 22);
            label2.TabIndex = 8;
            label2.Text = "Campaign ID";
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.FromArgb(247, 220, 143);
            textBox1.Location = new Point(173, 103);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(157, 27);
            textBox1.TabIndex = 9;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.FromArgb(247, 220, 143);
            textBox2.Location = new Point(94, 247);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(236, 27);
            textBox2.TabIndex = 11;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(91, 120, 105);
            label3.Location = new Point(25, 248);
            label3.Name = "label3";
            label3.Size = new Size(63, 22);
            label3.TabIndex = 10;
            label3.Text = "Class";
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.FromArgb(247, 220, 143);
            textBox3.Location = new Point(490, 243);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(185, 27);
            textBox3.TabIndex = 13;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(91, 120, 105);
            label4.Location = new Point(370, 244);
            label4.Name = "label4";
            label4.Size = new Size(114, 22);
            label4.TabIndex = 12;
            label4.Text = "Alignment";
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.FromArgb(247, 220, 143);
            textBox4.Location = new Point(173, 173);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(502, 27);
            textBox4.TabIndex = 15;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.FromArgb(91, 120, 105);
            label5.Location = new Point(25, 174);
            label5.Name = "label5";
            label5.Size = new Size(68, 22);
            label5.TabIndex = 14;
            label5.Text = "Name";
            // 
            // textBox5
            // 
            textBox5.BackColor = Color.FromArgb(247, 220, 143);
            textBox5.Location = new Point(412, 103);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(263, 27);
            textBox5.TabIndex = 17;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.FromArgb(91, 120, 105);
            label6.Location = new Point(352, 103);
            label6.Name = "label6";
            label6.Size = new Size(54, 22);
            label6.TabIndex = 16;
            label6.Text = "Title";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label21);
            groupBox1.Controls.Add(textBox10);
            groupBox1.Controls.Add(label20);
            groupBox1.Controls.Add(label19);
            groupBox1.Controls.Add(textBox8);
            groupBox1.Controls.Add(label18);
            groupBox1.Controls.Add(textBox7);
            groupBox1.Controls.Add(label17);
            groupBox1.Controls.Add(label16);
            groupBox1.Controls.Add(label15);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(textBox13);
            groupBox1.Controls.Add(label14);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(textBox11);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(textBox9);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(textBox6);
            groupBox1.Controls.Add(label7);
            groupBox1.Font = new Font("Verdana", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            groupBox1.ForeColor = Color.FromArgb(150, 206, 180);
            groupBox1.Location = new Point(46, 306);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(356, 330);
            groupBox1.TabIndex = 18;
            groupBox1.TabStop = false;
            groupBox1.Text = "Stats";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label21.ForeColor = Color.FromArgb(91, 120, 105);
            label21.Location = new Point(269, 224);
            label21.Name = "label21";
            label21.Size = new Size(48, 22);
            label21.TabIndex = 43;
            label21.Text = "/12";
            // 
            // textBox10
            // 
            textBox10.BackColor = Color.FromArgb(247, 220, 143);
            textBox10.Location = new Point(184, 218);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(79, 35);
            textBox10.TabIndex = 42;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label20.ForeColor = Color.FromArgb(91, 120, 105);
            label20.ImageAlign = ContentAlignment.MiddleLeft;
            label20.Location = new Point(184, 184);
            label20.Name = "label20";
            label20.Size = new Size(112, 22);
            label20.TabIndex = 41;
            label20.Text = "Willpower";
            label20.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label19.ForeColor = Color.FromArgb(91, 120, 105);
            label19.Location = new Point(115, 259);
            label19.Name = "label19";
            label19.Size = new Size(48, 22);
            label19.TabIndex = 40;
            label19.Text = "/20";
            // 
            // textBox8
            // 
            textBox8.BackColor = Color.FromArgb(247, 220, 143);
            textBox8.Location = new Point(75, 253);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(42, 35);
            textBox8.TabIndex = 39;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label18.ForeColor = Color.FromArgb(91, 120, 105);
            label18.Location = new Point(115, 129);
            label18.Name = "label18";
            label18.Size = new Size(48, 22);
            label18.TabIndex = 38;
            label18.Text = "/20";
            // 
            // textBox7
            // 
            textBox7.BackColor = Color.FromArgb(247, 220, 143);
            textBox7.Location = new Point(75, 123);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(42, 35);
            textBox7.TabIndex = 37;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label17.ForeColor = Color.FromArgb(91, 120, 105);
            label17.Location = new Point(292, 129);
            label17.Name = "label17";
            label17.Size = new Size(48, 22);
            label17.TabIndex = 36;
            label17.Text = "/20";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.ForeColor = Color.FromArgb(91, 120, 105);
            label16.Location = new Point(292, 64);
            label16.Name = "label16";
            label16.Size = new Size(48, 22);
            label16.TabIndex = 35;
            label16.Text = "/20";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label15.ForeColor = Color.FromArgb(91, 120, 105);
            label15.Location = new Point(115, 194);
            label15.Name = "label15";
            label15.Size = new Size(48, 22);
            label15.TabIndex = 34;
            label15.Text = "/20";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.FromArgb(91, 120, 105);
            label13.Location = new Point(115, 64);
            label13.Name = "label13";
            label13.Size = new Size(48, 22);
            label13.TabIndex = 33;
            label13.Text = "/20";
            // 
            // textBox13
            // 
            textBox13.BackColor = Color.FromArgb(247, 220, 143);
            textBox13.Location = new Point(252, 123);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(42, 35);
            textBox13.TabIndex = 32;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.ForeColor = Color.FromArgb(91, 120, 105);
            label14.Location = new Point(15, 287);
            label14.Name = "label14";
            label14.Size = new Size(0, 22);
            label14.TabIndex = 31;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.FromArgb(91, 120, 105);
            label11.ImageAlign = ContentAlignment.MiddleLeft;
            label11.Location = new Point(184, 129);
            label11.Name = "label11";
            label11.Size = new Size(52, 22);
            label11.TabIndex = 29;
            label11.Text = "CHA";
            label11.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // textBox11
            // 
            textBox11.BackColor = Color.FromArgb(247, 220, 143);
            textBox11.Location = new Point(252, 58);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(42, 35);
            textBox11.TabIndex = 28;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.FromArgb(91, 120, 105);
            label12.Location = new Point(184, 64);
            label12.Name = "label12";
            label12.RightToLeft = RightToLeft.No;
            label12.Size = new Size(53, 22);
            label12.TabIndex = 27;
            label12.Text = "CON";
            label12.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.FromArgb(91, 120, 105);
            label9.Location = new Point(7, 260);
            label9.Name = "label9";
            label9.Size = new Size(53, 22);
            label9.TabIndex = 25;
            label9.Text = "WIS";
            // 
            // textBox9
            // 
            textBox9.BackColor = Color.FromArgb(247, 220, 143);
            textBox9.Location = new Point(75, 188);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(42, 35);
            textBox9.TabIndex = 24;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.FromArgb(91, 120, 105);
            label10.Location = new Point(7, 194);
            label10.Name = "label10";
            label10.Size = new Size(51, 22);
            label10.TabIndex = 23;
            label10.Text = "DEX";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.FromArgb(91, 120, 105);
            label8.Location = new Point(7, 133);
            label8.Name = "label8";
            label8.Size = new Size(47, 22);
            label8.TabIndex = 21;
            label8.Text = "INT";
            // 
            // textBox6
            // 
            textBox6.BackColor = Color.FromArgb(247, 220, 143);
            textBox6.Location = new Point(75, 58);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(42, 35);
            textBox6.TabIndex = 20;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.FromArgb(91, 120, 105);
            label7.Location = new Point(7, 64);
            label7.Name = "label7";
            label7.Size = new Size(49, 22);
            label7.TabIndex = 19;
            label7.Text = "STR";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(textBox15);
            groupBox2.Controls.Add(textBox14);
            groupBox2.Controls.Add(textBox12);
            groupBox2.Controls.Add(label24);
            groupBox2.Controls.Add(label23);
            groupBox2.Controls.Add(label22);
            groupBox2.Font = new Font("Verdana", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            groupBox2.ForeColor = Color.FromArgb(150, 206, 180);
            groupBox2.Location = new Point(441, 306);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(230, 331);
            groupBox2.TabIndex = 19;
            groupBox2.TabStop = false;
            groupBox2.Text = "Gear";
            // 
            // textBox15
            // 
            textBox15.BackColor = Color.FromArgb(247, 220, 143);
            textBox15.Location = new Point(6, 260);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(218, 35);
            textBox15.TabIndex = 48;
            // 
            // textBox14
            // 
            textBox14.BackColor = Color.FromArgb(247, 220, 143);
            textBox14.Location = new Point(6, 170);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(218, 35);
            textBox14.TabIndex = 47;
            // 
            // textBox12
            // 
            textBox12.BackColor = Color.FromArgb(247, 220, 143);
            textBox12.Location = new Point(6, 64);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(218, 35);
            textBox12.TabIndex = 44;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label24.ForeColor = Color.FromArgb(91, 120, 105);
            label24.Location = new Point(6, 234);
            label24.Name = "label24";
            label24.RightToLeft = RightToLeft.No;
            label24.Size = new Size(77, 22);
            label24.TabIndex = 46;
            label24.Text = "Gear 3";
            label24.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label23.ForeColor = Color.FromArgb(91, 120, 105);
            label23.Location = new Point(6, 145);
            label23.Name = "label23";
            label23.RightToLeft = RightToLeft.No;
            label23.Size = new Size(77, 22);
            label23.TabIndex = 45;
            label23.Text = "Gear 2";
            label23.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label22.ForeColor = Color.FromArgb(91, 120, 105);
            label22.Location = new Point(6, 39);
            label22.Name = "label22";
            label22.RightToLeft = RightToLeft.No;
            label22.Size = new Size(77, 22);
            label22.TabIndex = 44;
            label22.Text = "Gear 1";
            label22.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label25.ForeColor = Color.FromArgb(91, 120, 105);
            label25.Location = new Point(731, 27);
            label25.Name = "label25";
            label25.Size = new Size(86, 22);
            label25.TabIndex = 20;
            label25.Text = "Attacks";
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label26.ForeColor = Color.FromArgb(91, 120, 105);
            label26.Location = new Point(731, 169);
            label26.Name = "label26";
            label26.Size = new Size(132, 22);
            label26.TabIndex = 21;
            label26.Text = "Background";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label27.ForeColor = Color.FromArgb(91, 120, 105);
            label27.Location = new Point(731, 376);
            label27.Name = "label27";
            label27.Size = new Size(157, 22);
            label27.TabIndex = 22;
            label27.Text = "Talents/Spells";
            // 
            // richTextBox1
            // 
            richTextBox1.BackColor = Color.FromArgb(247, 220, 143);
            richTextBox1.Location = new Point(737, 194);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(479, 154);
            richTextBox1.TabIndex = 24;
            richTextBox1.Text = "";
            // 
            // richTextBox2
            // 
            richTextBox2.BackColor = Color.FromArgb(247, 220, 143);
            richTextBox2.ForeColor = SystemColors.WindowText;
            richTextBox2.Location = new Point(737, 52);
            richTextBox2.Name = "richTextBox2";
            richTextBox2.Size = new Size(479, 96);
            richTextBox2.TabIndex = 25;
            richTextBox2.Text = "";
            // 
            // richTextBox3
            // 
            richTextBox3.BackColor = Color.FromArgb(247, 220, 143);
            richTextBox3.Location = new Point(737, 401);
            richTextBox3.Name = "richTextBox3";
            richTextBox3.Size = new Size(479, 161);
            richTextBox3.TabIndex = 26;
            richTextBox3.Text = "";
            // 
            // saveandrettocampaignDB
            // 
            saveandrettocampaignDB.AccessibleRole = AccessibleRole.None;
            saveandrettocampaignDB.BackColor = Color.FromArgb(150, 206, 180);
            saveandrettocampaignDB.FlatAppearance.BorderSize = 0;
            saveandrettocampaignDB.FlatAppearance.MouseDownBackColor = Color.FromArgb(255, 255, 173);
            saveandrettocampaignDB.FlatAppearance.MouseOverBackColor = Color.FromArgb(91, 120, 105);
            saveandrettocampaignDB.FlatStyle = FlatStyle.Flat;
            saveandrettocampaignDB.Font = new Font("Verdana", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            saveandrettocampaignDB.ForeColor = Color.FromArgb(91, 120, 105);
            saveandrettocampaignDB.Location = new Point(944, 585);
            saveandrettocampaignDB.Name = "saveandrettocampaignDB";
            saveandrettocampaignDB.RightToLeft = RightToLeft.No;
            saveandrettocampaignDB.Size = new Size(272, 52);
            saveandrettocampaignDB.TabIndex = 27;
            saveandrettocampaignDB.Text = "Save and Return to Campaign";
            saveandrettocampaignDB.UseVisualStyleBackColor = false;
            saveandrettocampaignDB.Click += saveandrettocampaignDB_Click;
            // 
            // retBT
            // 
            retBT.AccessibleRole = AccessibleRole.None;
            retBT.BackColor = Color.FromArgb(150, 206, 180);
            retBT.FlatAppearance.BorderSize = 0;
            retBT.FlatAppearance.MouseDownBackColor = Color.FromArgb(255, 255, 173);
            retBT.FlatAppearance.MouseOverBackColor = Color.FromArgb(91, 120, 105);
            retBT.FlatStyle = FlatStyle.Flat;
            retBT.Font = new Font("Verdana", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            retBT.ForeColor = Color.FromArgb(91, 120, 105);
            retBT.Location = new Point(737, 585);
            retBT.Name = "retBT";
            retBT.RightToLeft = RightToLeft.No;
            retBT.Size = new Size(169, 52);
            retBT.TabIndex = 49;
            retBT.Text = "Cancel";
            retBT.UseVisualStyleBackColor = false;
            retBT.Click += retBT_Click;
            // 
            // createnewchara
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(251, 235, 171);
            ClientSize = new Size(1262, 673);
            Controls.Add(retBT);
            Controls.Add(saveandrettocampaignDB);
            Controls.Add(richTextBox3);
            Controls.Add(richTextBox2);
            Controls.Add(richTextBox1);
            Controls.Add(label27);
            Controls.Add(label26);
            Controls.Add(label25);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(textBox5);
            Controls.Add(label6);
            Controls.Add(textBox4);
            Controls.Add(label5);
            Controls.Add(textBox3);
            Controls.Add(label4);
            Controls.Add(textBox2);
            Controls.Add(label3);
            Controls.Add(textBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "createnewchara";
            Text = "Create a New Character";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label3;
        private TextBox textBox3;
        private Label label4;
        private TextBox textBox4;
        private Label label5;
        private TextBox textBox5;
        private Label label6;
        private GroupBox groupBox1;
        private TextBox textBox13;
        private Label label14;
        private Label label11;
        private TextBox textBox11;
        private Label label12;
        private Label label9;
        private TextBox textBox9;
        private Label label10;
        private Label label8;
        private TextBox textBox6;
        private Label label7;
        private Label label13;
        private Label label17;
        private Label label16;
        private Label label15;
        private Label label19;
        private TextBox textBox8;
        private Label label18;
        private TextBox textBox7;
        private Label label20;
        private Label label21;
        private TextBox textBox10;
        private GroupBox groupBox2;
        private TextBox textBox15;
        private TextBox textBox14;
        private TextBox textBox12;
        private Label label24;
        private Label label23;
        private Label label22;
        private Label label25;
        private Label label26;
        private Label label27;
        private RichTextBox richTextBox1;
        private RichTextBox richTextBox2;
        private RichTextBox richTextBox3;
        private Button saveandrettocampaignDB;
        private Button retBT;
    }
}