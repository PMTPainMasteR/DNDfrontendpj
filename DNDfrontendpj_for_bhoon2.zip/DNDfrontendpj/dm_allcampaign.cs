﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DNDfrontendpj
{
    public partial class dm_allcampaign : Form
    {
        public dm_allcampaign()
        {
            InitializeComponent();
        }

        private void ret2dmallcampaignBT_Click(object sender, EventArgs e)
        {
            //wrong name eeklaew ret2dmallcampaignBT_Click -> return to login
            login login = new login();
            login.Show();
            this.Close();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            //search for campaign id to see the database on the same page
            //not close page


        }

        private void button1_Click(object sender, EventArgs e)
        {
            dm_newcampaign dm_Newcampaign = new dm_newcampaign();
            dm_Newcampaign.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dm_editcampaign dm_Editcampaign = new dm_editcampaign();
            dm_Editcampaign.Show();
            //this.Close();
        }

        private void continuecampBT_Click(object sender, EventArgs e)
        {
            dm_playerstat dm_Playerstat = new dm_playerstat();
            dm_Playerstat.Show();   
            this.Close();
        }
    }
}
