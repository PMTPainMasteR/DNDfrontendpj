﻿namespace DNDfrontendpj
{
    partial class Signup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            groupBox1 = new GroupBox();
            label8 = new Label();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            groupBox2 = new GroupBox();
            checkBox2 = new CheckBox();
            label7 = new Label();
            checkBox1 = new CheckBox();
            label3 = new Label();
            ret2loginBT = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Verdana", 48F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(91, 120, 105);
            label1.Location = new Point(461, 49);
            label1.Name = "label1";
            label1.Size = new Size(387, 97);
            label1.TabIndex = 2;
            label1.Text = "Sign Up";
            label1.TextAlign = ContentAlignment.TopCenter;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(textBox3);
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.ForeColor = Color.FromArgb(247, 220, 143);
            groupBox1.Location = new Point(79, 176);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(527, 467);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Verdana", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.FromArgb(91, 120, 105);
            label8.Location = new Point(23, 39);
            label8.Name = "label8";
            label8.Size = new Size(297, 48);
            label8.TabIndex = 10;
            label8.Text = "General info";
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.FromArgb(247, 220, 143);
            textBox3.BorderStyle = BorderStyle.None;
            textBox3.Font = new Font("Verdana", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox3.Location = new Point(23, 395);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(423, 28);
            textBox3.TabIndex = 8;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.FromArgb(247, 220, 143);
            textBox2.BorderStyle = BorderStyle.None;
            textBox2.Font = new Font("Verdana", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox2.Location = new Point(23, 279);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(423, 28);
            textBox2.TabIndex = 7;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.FromArgb(247, 220, 143);
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Font = new Font("Verdana", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(23, 177);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(423, 28);
            textBox1.TabIndex = 6;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Verdana", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.FromArgb(91, 120, 105);
            label6.Location = new Point(23, 332);
            label6.Name = "label6";
            label6.Size = new Size(304, 34);
            label6.TabIndex = 5;
            label6.Text = "Confirm Password";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Verdana", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.FromArgb(91, 120, 105);
            label5.Location = new Point(23, 222);
            label5.Name = "label5";
            label5.Size = new Size(169, 34);
            label5.TabIndex = 4;
            label5.Text = "Password";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Verdana", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(91, 120, 105);
            label4.Location = new Point(23, 121);
            label4.Name = "label4";
            label4.Size = new Size(176, 34);
            label4.TabIndex = 3;
            label4.Text = "Username";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(checkBox2);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(checkBox1);
            groupBox2.Controls.Add(label3);
            groupBox2.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox2.ForeColor = Color.FromArgb(150, 206, 180);
            groupBox2.Location = new Point(665, 176);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(533, 256);
            groupBox2.TabIndex = 4;
            groupBox2.TabStop = false;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Font = new Font("Verdana", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            checkBox2.ForeColor = Color.FromArgb(91, 120, 105);
            checkBox2.Location = new Point(46, 177);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(357, 38);
            checkBox2.TabIndex = 7;
            checkBox2.Text = "Adventurer (Player)";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Verdana", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.FromArgb(91, 120, 105);
            label7.Location = new Point(46, 39);
            label7.Name = "label7";
            label7.Size = new Size(255, 48);
            label7.TabIndex = 9;
            label7.Text = "Sign up as";
            label7.Click += label7_Click;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Font = new Font("Verdana", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            checkBox1.ForeColor = Color.FromArgb(91, 120, 105);
            checkBox1.Location = new Point(46, 117);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(406, 38);
            checkBox1.TabIndex = 6;
            checkBox1.Text = "Duengeon Master (DM)";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Verdana", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(91, 120, 105);
            label3.Location = new Point(106, 211);
            label3.Name = "label3";
            label3.Size = new Size(0, 45);
            label3.TabIndex = 2;
            label3.TextAlign = ContentAlignment.TopCenter;
            // 
            // ret2loginBT
            // 
            ret2loginBT.BackColor = Color.FromArgb(150, 206, 180);
            ret2loginBT.FlatAppearance.BorderSize = 0;
            ret2loginBT.FlatAppearance.MouseOverBackColor = Color.FromArgb(247, 220, 143);
            ret2loginBT.FlatStyle = FlatStyle.Flat;
            ret2loginBT.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ret2loginBT.ForeColor = Color.FromArgb(91, 120, 105);
            ret2loginBT.Location = new Point(937, 564);
            ret2loginBT.Name = "ret2loginBT";
            ret2loginBT.Size = new Size(261, 52);
            ret2loginBT.TabIndex = 5;
            ret2loginBT.Text = "Save and Return to login";
            ret2loginBT.UseVisualStyleBackColor = false;
            ret2loginBT.Click += ret2loginBT_Click;
            // 
            // Signup
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(251, 235, 171);
            ClientSize = new Size(1262, 673);
            Controls.Add(ret2loginBT);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Name = "Signup";
            Text = "Sign Up";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Label label3;
        private Label label6;
        private Label label5;
        private Label label4;
        private TextBox textBox1;
        private TextBox textBox3;
        private TextBox textBox2;
        private Button ret2loginBT;
        private Label label7;
        private Label label8;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
    }
}