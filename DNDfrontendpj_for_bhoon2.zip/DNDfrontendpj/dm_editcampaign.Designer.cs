﻿namespace DNDfrontendpj
{
    partial class dm_editcampaign
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ret2camdbBT = new Button();
            richTextBox2 = new RichTextBox();
            label1 = new Label();
            richTextBox1 = new RichTextBox();
            textBox1 = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            label2 = new Label();
            radioButton3 = new RadioButton();
            SuspendLayout();
            // 
            // ret2camdbBT
            // 
            ret2camdbBT.BackColor = Color.FromArgb(150, 206, 180);
            ret2camdbBT.FlatAppearance.BorderSize = 0;
            ret2camdbBT.FlatAppearance.MouseOverBackColor = Color.FromArgb(247, 220, 143);
            ret2camdbBT.FlatStyle = FlatStyle.Flat;
            ret2camdbBT.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ret2camdbBT.ForeColor = Color.FromArgb(91, 120, 105);
            ret2camdbBT.Location = new Point(924, 584);
            ret2camdbBT.Name = "ret2camdbBT";
            ret2camdbBT.Size = new Size(261, 55);
            ret2camdbBT.TabIndex = 25;
            ret2camdbBT.Text = "Save and Continue Campaign";
            ret2camdbBT.UseVisualStyleBackColor = false;
            // 
            // richTextBox2
            // 
            richTextBox2.BackColor = Color.FromArgb(247, 220, 143);
            richTextBox2.Location = new Point(325, 290);
            richTextBox2.Name = "richTextBox2";
            richTextBox2.Size = new Size(338, 242);
            richTextBox2.TabIndex = 24;
            richTextBox2.Text = "";
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Verdana", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(91, 120, 105);
            label1.Location = new Point(391, 58);
            label1.Name = "label1";
            label1.Size = new Size(518, 73);
            label1.TabIndex = 23;
            label1.Text = "Edit Campaign";
            label1.TextAlign = ContentAlignment.TopCenter;
            // 
            // richTextBox1
            // 
            richTextBox1.BackColor = Color.FromArgb(247, 220, 143);
            richTextBox1.Location = new Point(773, 244);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(412, 288);
            richTextBox1.TabIndex = 22;
            richTextBox1.Text = "";
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.FromArgb(247, 220, 143);
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Font = new Font("Verdana", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(325, 212);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(338, 28);
            textBox1.TabIndex = 21;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Verdana", 13.8F, FontStyle.Bold);
            label6.ForeColor = Color.FromArgb(91, 120, 105);
            label6.Location = new Point(763, 200);
            label6.Name = "label6";
            label6.Size = new Size(294, 28);
            label6.TabIndex = 20;
            label6.Text = "Campaign Description";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Verdana", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.FromArgb(91, 120, 105);
            label5.Location = new Point(77, 286);
            label5.Name = "label5";
            label5.Size = new Size(205, 28);
            label5.TabIndex = 19;
            label5.Text = "Setting/Theme";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Verdana", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(91, 120, 105);
            label4.Location = new Point(77, 206);
            label4.Name = "label4";
            label4.Size = new Size(220, 28);
            label4.TabIndex = 18;
            label4.Text = "Campaign Name";
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            radioButton1.ForeColor = Color.FromArgb(91, 120, 105);
            radioButton1.Location = new Point(351, 594);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(134, 29);
            radioButton1.TabIndex = 26;
            radioButton1.TabStop = true;
            radioButton1.Text = "On going";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            radioButton2.ForeColor = Color.FromArgb(91, 120, 105);
            radioButton2.Location = new Point(538, 594);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(100, 29);
            radioButton2.TabIndex = 27;
            radioButton2.TabStop = true;
            radioButton2.Text = "Finish";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Verdana", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(91, 120, 105);
            label2.Location = new Point(77, 595);
            label2.Name = "label2";
            label2.Size = new Size(228, 28);
            label2.TabIndex = 28;
            label2.Text = "Campaign Status";
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Font = new Font("Verdana", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            radioButton3.ForeColor = Color.FromArgb(160, 50, 50);
            radioButton3.Location = new Point(688, 594);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(129, 29);
            radioButton3.TabIndex = 29;
            radioButton3.TabStop = true;
            radioButton3.Text = "Dropped";
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // dm_editcampaign
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(251, 235, 171);
            ClientSize = new Size(1262, 673);
            Controls.Add(radioButton3);
            Controls.Add(label2);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Controls.Add(ret2camdbBT);
            Controls.Add(richTextBox2);
            Controls.Add(label1);
            Controls.Add(richTextBox1);
            Controls.Add(textBox1);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Name = "dm_editcampaign";
            Text = "Edit Campaign";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button ret2camdbBT;
        private RichTextBox richTextBox2;
        private Label label1;
        private RichTextBox richTextBox1;
        private TextBox textBox1;
        private Label label6;
        private Label label5;
        private Label label4;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private Label label2;
        private RadioButton radioButton3;
    }
}