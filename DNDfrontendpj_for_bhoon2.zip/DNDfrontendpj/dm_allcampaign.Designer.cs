﻿namespace DNDfrontendpj
{
    partial class dm_allcampaign
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dm_allcampaign));
            label2 = new Label();
            ret2dmallcampaignBT = new PictureBox();
            continuecampBT = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            charstat_DGV = new DataGridView();
            label1 = new Label();
            searchchar_TB = new TextBox();
            button5 = new Button();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)ret2dmallcampaignBT).BeginInit();
            ((System.ComponentModel.ISupportInitialize)charstat_DGV).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Verdana", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(255, 204, 92);
            label2.Location = new Point(419, 105);
            label2.Name = "label2";
            label2.Size = new Size(163, 18);
            label2.TabIndex = 27;
            label2.Text = "Enter Campaign ID";
            label2.TextAlign = ContentAlignment.MiddleRight;
            // 
            // ret2dmallcampaignBT
            // 
            ret2dmallcampaignBT.BackColor = Color.Transparent;
            ret2dmallcampaignBT.BackgroundImage = (Image)resources.GetObject("ret2dmallcampaignBT.BackgroundImage");
            ret2dmallcampaignBT.BackgroundImageLayout = ImageLayout.Zoom;
            ret2dmallcampaignBT.BorderStyle = BorderStyle.FixedSingle;
            ret2dmallcampaignBT.ErrorImage = (Image)resources.GetObject("ret2dmallcampaignBT.ErrorImage");
            ret2dmallcampaignBT.InitialImage = (Image)resources.GetObject("ret2dmallcampaignBT.InitialImage");
            ret2dmallcampaignBT.Location = new Point(63, 31);
            ret2dmallcampaignBT.Name = "ret2dmallcampaignBT";
            ret2dmallcampaignBT.Size = new Size(77, 39);
            ret2dmallcampaignBT.TabIndex = 26;
            ret2dmallcampaignBT.TabStop = false;
            ret2dmallcampaignBT.Click += ret2dmallcampaignBT_Click;
            // 
            // continuecampBT
            // 
            continuecampBT.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            continuecampBT.BackColor = Color.FromArgb(148, 201, 176);
            continuecampBT.FlatAppearance.BorderColor = Color.Silver;
            continuecampBT.FlatAppearance.BorderSize = 0;
            continuecampBT.FlatAppearance.MouseOverBackColor = Color.FromArgb(247, 220, 143);
            continuecampBT.FlatStyle = FlatStyle.Flat;
            continuecampBT.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            continuecampBT.ForeColor = Color.FromArgb(91, 120, 105);
            continuecampBT.Image = (Image)resources.GetObject("continuecampBT.Image");
            continuecampBT.ImageAlign = ContentAlignment.MiddleLeft;
            continuecampBT.Location = new Point(955, 622);
            continuecampBT.Name = "continuecampBT";
            continuecampBT.Size = new Size(245, 35);
            continuecampBT.TabIndex = 24;
            continuecampBT.Text = "Continue Campaign";
            continuecampBT.TextAlign = ContentAlignment.MiddleRight;
            continuecampBT.TextImageRelation = TextImageRelation.ImageBeforeText;
            continuecampBT.UseVisualStyleBackColor = false;
            continuecampBT.Click += continuecampBT_Click;
            // 
            // button3
            // 
            button3.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button3.BackColor = Color.FromArgb(148, 201, 176);
            button3.FlatAppearance.BorderColor = Color.Silver;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.MouseOverBackColor = Color.FromArgb(247, 220, 143);
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.FromArgb(91, 120, 105);
            button3.Image = (Image)resources.GetObject("button3.Image");
            button3.ImageAlign = ContentAlignment.MiddleLeft;
            button3.Location = new Point(373, 622);
            button3.Name = "button3";
            button3.Size = new Size(245, 35);
            button3.TabIndex = 23;
            button3.Text = "Edit Campaign";
            button3.TextAlign = ContentAlignment.MiddleRight;
            button3.TextImageRelation = TextImageRelation.ImageBeforeText;
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button2.BackColor = Color.FromArgb(148, 201, 176);
            button2.FlatAppearance.BorderColor = Color.Silver;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatAppearance.MouseOverBackColor = Color.FromArgb(247, 220, 143);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.FromArgb(91, 120, 105);
            button2.Image = (Image)resources.GetObject("button2.Image");
            button2.ImageAlign = ContentAlignment.MiddleLeft;
            button2.Location = new Point(668, 622);
            button2.Name = "button2";
            button2.Size = new Size(245, 35);
            button2.TabIndex = 22;
            button2.Text = "Delete Campaign";
            button2.TextAlign = ContentAlignment.MiddleRight;
            button2.TextImageRelation = TextImageRelation.ImageBeforeText;
            button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            button1.BackColor = Color.FromArgb(148, 201, 176);
            button1.FlatAppearance.BorderColor = Color.Silver;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatAppearance.MouseOverBackColor = Color.FromArgb(247, 220, 143);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Verdana", 9.8F, FontStyle.Bold);
            button1.ForeColor = Color.FromArgb(91, 120, 105);
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.Location = new Point(63, 623);
            button1.Name = "button1";
            button1.Size = new Size(245, 35);
            button1.TabIndex = 21;
            button1.Text = "Add New Campaign";
            button1.TextImageRelation = TextImageRelation.ImageBeforeText;
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // charstat_DGV
            // 
            charstat_DGV.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            charstat_DGV.BackgroundColor = Color.FromArgb(247, 220, 143);
            charstat_DGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            charstat_DGV.GridColor = Color.FromArgb(91, 120, 105);
            charstat_DGV.Location = new Point(59, 178);
            charstat_DGV.Name = "charstat_DGV";
            charstat_DGV.RowHeadersWidth = 51;
            charstat_DGV.Size = new Size(1141, 416);
            charstat_DGV.TabIndex = 18;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Verdana", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(91, 120, 105);
            label1.Location = new Point(311, 15);
            label1.Name = "label1";
            label1.Size = new Size(706, 73);
            label1.TabIndex = 17;
            label1.Text = "Campaign Overview";
            label1.TextAlign = ContentAlignment.TopCenter;
            // 
            // searchchar_TB
            // 
            searchchar_TB.BackColor = Color.FromArgb(247, 220, 143);
            searchchar_TB.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            searchchar_TB.Location = new Point(419, 126);
            searchchar_TB.Name = "searchchar_TB";
            searchchar_TB.Size = new Size(427, 28);
            searchchar_TB.TabIndex = 29;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(150, 206, 180);
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatAppearance.MouseOverBackColor = Color.FromArgb(247, 220, 143);
            button5.FlatStyle = FlatStyle.Flat;
            button5.ForeColor = Color.FromArgb(145, 199, 176);
            button5.Image = (Image)resources.GetObject("button5.Image");
            button5.Location = new Point(852, 105);
            button5.Name = "button5";
            button5.Size = new Size(49, 49);
            button5.TabIndex = 28;
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Verdana", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(255, 204, 92);
            label3.Location = new Point(145, 41);
            label3.Name = "label3";
            label3.Size = new Size(135, 18);
            label3.TabIndex = 30;
            label3.Text = "Return to Login";
            label3.TextAlign = ContentAlignment.MiddleRight;
            // 
            // dm_allcampaign
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 238, 173);
            ClientSize = new Size(1262, 673);
            Controls.Add(label3);
            Controls.Add(searchchar_TB);
            Controls.Add(button5);
            Controls.Add(label2);
            Controls.Add(ret2dmallcampaignBT);
            Controls.Add(continuecampBT);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(charstat_DGV);
            Controls.Add(label1);
            Name = "dm_allcampaign";
            Text = "Campaign Overview";
            ((System.ComponentModel.ISupportInitialize)ret2dmallcampaignBT).EndInit();
            ((System.ComponentModel.ISupportInitialize)charstat_DGV).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label2;
        private PictureBox ret2dmallcampaignBT;
        private Button continuecampBT;
        private Button button3;
        private Button button2;
        private Button button1;
        private DataGridView charstat_DGV;
        private Label label1;
        private TextBox searchchar_TB;
        private Button button5;
        private Label label3;
    }
}