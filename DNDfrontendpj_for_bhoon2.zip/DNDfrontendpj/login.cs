﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DNDfrontendpj
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            // Create an instance of the Signup form
            Signup signupForm = new Signup();

            // Show the Signup form
            signupForm.Show();

            // Optionally, close the current login form if needed
            // this.Close();
        }

        private void nextbt_Click(object sender, EventArgs e)
        {
            //if user is a dm go to dm_allcampaign.cs

            // Create an instance of the Signup form
            dm_allcampaign dmallcampaignDB = new dm_allcampaign();

            // Show the Signup form
            dmallcampaignDB.Show();

            // Optionally, close the current login form if needed
            this.Close();

            //if user is a dm go to player_welcome.cs

            // Create an instance of the Signup form
            player_welcome playerwelcomePAGE = new player_welcome();

            // Show the Signup form
            playerwelcomePAGE.Show();

            // Optionally, close the current login form if needed
            this.Close();

        }

        private void login_Load(object sender, EventArgs e)
        {
            //does nothing
        }
    }
}
