using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DNDfrontendpj
{
    public partial class character_stat : Form
    {
        public character_stat()
        {
            InitializeComponent();
        }

        private void campname_TXT_Click(object sender, EventArgs e)
        {

        }

        private void ret2welcomeplayer_Click(object sender, EventArgs e)
        {
            player_welcome playerwelcome = new player_welcome();
            playerwelcome.Show();
            this.Close();
        }

        private void searchchar_BT_Click(object sender, EventArgs e)
        {
            searchchar go2search = new searchchar();
            go2search.Show();
            //this.Close();
        }

        private void viewinven_BT_Click(object sender, EventArgs e)
        {
            player_inventory inventory = new player_inventory();
            inventory.Show();
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            //does nothing

        }
    }
}
