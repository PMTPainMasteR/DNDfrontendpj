﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DNDfrontendpj
{
    public partial class createnewchara : Form
    {
        public createnewchara()
        {
            InitializeComponent();
        }

        private void saveandrettocampaignDB_Click(object sender, EventArgs e)
        {
            //if the user is dm go to dm exclusive db
            // Create an instance
            dm_playerstat dmplayerstat = new dm_playerstat();
            dmplayerstat.Show();
            this.Close();

            //if the user is player go to player db
            player_charstat playercharDB = new player_charstat();
            playercharDB.Show();
            this.Close();
        }

        private void retBT_Click(object sender, EventArgs e)
        {
            //if player click this button it will return to welcome player
            player_welcome player_Welcome = new player_welcome();
            player_Welcome.Show();
            this.Close();

            //if a dm click this button, it will return to the dm_playerstats
            dm_playerstat playerstat = new dm_playerstat();
            playerstat.Show();
            this.Close();
        }
    }
}
